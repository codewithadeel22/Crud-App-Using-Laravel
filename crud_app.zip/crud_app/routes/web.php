<?php

use App\Http\Controllers\usercontroller;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/',[usercontroller::class,'ShowUser'])->name('home');
Route::get('/user/{id}',[usercontroller::class,'singleuser'])->name('view.user');
Route::POST('/add',[usercontroller::class,'addUser'])->name('addUser');
Route::view('/newuser','adduser');
Route::get('/delete/{id}',[usercontroller::class,'deletuser'])->name('deleteuser');
