<?php

namespace Database\Seeders;

use App\Models\teacher;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class teacherseeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $students=collect([
            ['name'=>'Nadeem',
             'email'=>'nadeem76@gmail.com',
              'age'=>'25',
            'address'=>'Mandi Town',
             'city'=>'jhung',
            'phone'=>'0346789543',
        'password'=>'3456'],

        ['name'=>'Saqib',
        'email'=>'Saqib@gmail.com',
         'age'=>'23',
       'address'=>'Model Town',
        'city'=>'Lahore',
       'phone'=>'0345343453',
   'password'=>'3456'],

   ['name'=>'Mubashir',
   'email'=>'Mubashir@gmail.com',
    'age'=>'30',
  'address'=>'Sikandrpur',
   'city'=>'Karachi',
  'phone'=>'0307923245',
'password'=>'3456'],
           
['name'=>'Zubair',
'email'=>'Zubair@gmail.com',
 'age'=>'20',
'address'=>'NaseerAbad',
'city'=>'Layyah',
'phone'=>'03333333333',
'password'=>'3456'],

['name'=>'Tehseen',
'email'=>'Tehseen56789@gmail.com',
 'age'=>'40',
'address'=>'Hashmi Town',
'city'=>'Faislabad',
'phone'=>'0304567321',
'password'=>'3456'],

['name'=>'kamran',
'email'=>'kamran234@gmail.com',
 'age'=>'21',
'address'=>'Quidabad',
'city'=>'Multan',
'phone'=>'0323456789',
'password'=>'3456']
        ]);
        $students->each(function ($student){
            teacher::insert($student);
        });
    }
}
