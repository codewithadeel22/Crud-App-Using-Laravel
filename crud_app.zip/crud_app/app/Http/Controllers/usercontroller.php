<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use Illuminate\Support\Facades\Validator;
class usercontroller extends Controller
{
    public function ShowUser(){
        $users=DB::table('teachers')->get();
        return view('allusers',['data'=>$users]);
    }
    public function singleuser(string $id){
        $users=DB::table('users')->where('id',$id)->get();
        return $users;
    }
public function addUser(Request $req){
    $validator = Validator::make($req->all(), [
        'useremail' => 'required|email', // Define validation rules for email
        // Add other validation rules for different fields if needed
    ]);

    if ($validator->fails()) {
        return back()->withErrors($validator)->withInput();
    }
    $user=DB::table('teachers')->insert([
        'name'=>$req->username,
        'email'=>$req->useremail,
        'age'=>$req->userage,
        'password'=> $req->userpassword,
        'city'=>$req->usercity,
        'address'=>$req->useraddress,
        'phone'=>$req->userphonenumber,
    ]);
    if($user){
        return redirect()->route('home');
    }
    return back()->withInput()->withErrors(['email' => 'Email cannot be empty']);
}
public function delete(string $id){
    $user=DB::table('teachers')
    ->where ('id',$id)
    ->delete();
}
}
