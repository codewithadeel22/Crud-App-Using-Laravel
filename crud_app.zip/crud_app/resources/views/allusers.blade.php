<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
    <style>
       
       .custom-table {
        width: 10%;
        margin: auto;
        padding: 3rem;
       }

    </style>
</head>
<body>
    <div class="table-container">
        <a href="/newuser" class="btn btn-success btn-sm mb-3">Add Users</a>
        <div class="table-responsive">
            <table class="table table-bordered table-striped custom-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Age</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>Phone</th>
                        <th>Password</th>
                        <th>View</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Loop through the data to populate the table -->
                    @foreach ($data as $id => $user)
                    <tr>
                        <td>{{$user->id}}</td>
                        <td>{{$user->name}}</td>
                        <td>{{$user->email}}</td>
                        <td>{{$user->age}}</td>
                        <td>{{$user->address}}</td>
                        <td>{{$user->city}}</td>
                        <td>{{$user->phone}}</td>
                        <td>{{$user->password}}</td>
                        <td><a href="{{route('view.user',$user->id)}}">View</a></td>
                        <td><a href="{{route('deleteuser',$user->id)}}" class="btn btn-danger btn-sm mb-3">Delete</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
