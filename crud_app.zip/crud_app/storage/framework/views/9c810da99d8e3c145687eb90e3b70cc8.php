<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-4">
                <h1>Add New Users</h1>
                <form action="<?php echo e(route('addUser')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                   <div class="mb-3">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" name="username"/>
                   </div>
                   <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="text" class="form-control" name="useremail"/>
                   </div>
                   <div class="mb-3">
                    <label class="form-label">Age</label>
                    <input type="text" class="form-control" name="userage"/>
                   </div>
                   <div class="mb-3">
                    <label class="form-label">City</label>
                    <input type="text" class="form-control" name="usercity"/>
                   </div>
                   <div class="mb-3">
                    <label class="form-label">Address</label>
                    <input type="text" class="form-control" name="useraddress"/>
                   </div>
                   <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="text" class="form-control" name="userpassword"/>
                   </div>
                   <div class="mb-3">
                    <label class="form-label">phone Number</label>
                    <input type="text" class="form-control" name="userphonenumber"/>
                   </div>
                   <button type="submit" class="btn btn-primary btn-sm mb-3">Submit</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\User\Desktop\crud app laravel\crud_app\resources\views/adduser.blade.php ENDPATH**/ ?>